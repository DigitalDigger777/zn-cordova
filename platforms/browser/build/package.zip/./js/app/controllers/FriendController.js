/**
 * Created by korman on 23.11.16.
 */

define([], function(){
    return {
        showList: function(page){
            //TODO: show list of friend's
            console.log('friend list');
        },
        showItem: function(id){
            //TODO: show friend
            console.log('friend item');
        }
    }
});