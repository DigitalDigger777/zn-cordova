/**
 * Created by korman on 23.11.16.
 */

define([], function(){
    return {
        showList: function(page){
            //TODO: release show coupon list
            console.log('coupon list');
        },
        showItem: function(id){
            //TODO: release show item list
            console.log('coupon item');


        }
    }
});