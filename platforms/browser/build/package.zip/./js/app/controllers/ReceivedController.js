/**
 * Created by korman on 23.11.16.
 */

define([], function(){
    return {
        showList: function(page) {
            //TODO: show list
            console.log('received list');
        },
        showItem: function(id) {
            //TODO: show item
            console.log('received item');
        }
    }
});