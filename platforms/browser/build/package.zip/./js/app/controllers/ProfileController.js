/**
 * Created by korman on 23.11.16.
 */

define([], function(){
    return {
        showProfile: function(){
            //TODO: release show profile
            console.log('show profile');
        }
    }
});